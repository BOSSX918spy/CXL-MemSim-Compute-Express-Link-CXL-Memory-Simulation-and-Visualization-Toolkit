import numpy as np
import pandas as pd

class MemorySystem:
    def __init__(self, name, base_latency_ns, bandwidth_gbps):
        self.name = name
        self.base_latency = base_latency_ns
        self.bandwidth = bandwidth_gbps

    def simulate_access(self, size_kb, access_pattern="random"):
        # bandwidth factor: bigger accesses → more latency
        bandwidth_penalty = (size_kb / 1024) / self.bandwidth * 100  

        # access pattern penalty
        if access_pattern == "random":
            pattern_penalty = np.random.uniform(20, 60)
        else:
            pattern_penalty = np.random.uniform(5, 15)

        latency = self.base_latency + bandwidth_penalty + pattern_penalty
        return latency


def run_simulation():
    ddr5 = MemorySystem("DDR5", base_latency_ns=80, bandwidth_gbps=60)
    cxl = MemorySystem("CXL_Type3", base_latency_ns=350, bandwidth_gbps=32)

    results = []
    for size in [4, 16, 64, 256, 512, 1024]:  # KB
        for pattern in ["random", "sequential"]:
            results.append({
                "size_kb": size,
                "pattern": pattern,
                "DDR5_latency_ns": ddr5.simulate_access(size, pattern),
                "CXL_latency_ns": cxl.simulate_access(size, pattern),
            })

    return pd.DataFrame(results)


if __name__ == "__main__":
    df = run_simulation()
    df.to_csv("/Users/bossx918spyder/Documents/CXL Research/CXL-MemSim/data/telemetry_samples.csv", index=False)
    print("Simulation complete. Saved to /Users/bossx918spyder/Documents/CXL Research/CXL-MemSim/data/telemetry_samples.csv")
