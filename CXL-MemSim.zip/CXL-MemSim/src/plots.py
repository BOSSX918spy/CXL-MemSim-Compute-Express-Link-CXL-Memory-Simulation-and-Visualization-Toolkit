import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = "/Users/bossx918spyder/Documents/CXL Research/CXL-MemSim"
DATA_FILE = os.path.join(BASE_DIR, "data", "telemetry_samples.csv")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

def plot_latency_and_bandwidth():
    df = pd.read_csv(DATA_FILE)
    print("Columns in CSV:", df.columns)

    # --- LATENCY PLOT ---
    plt.figure(figsize=(8, 6))
    sns.lineplot(data=df, x="size_kb", y="DDR5_latency_ns", label="DDR5")
    sns.lineplot(data=df, x="size_kb", y="CXL_latency_ns", label="CXL-Type3")
    plt.xlabel("Access Size (KB)")
    plt.ylabel("Latency (ns)")
    plt.title("DDR5 vs CXL Memory Latency Curve")
    plt.grid(True)
    plt.savefig(os.path.join(RESULTS_DIR, "latency_curve.png"), dpi=600)
    plt.show()

    # --- BANDWIDTH PLOT ---
    df["DDR5_bandwidth_MBps"] = df["size_kb"] / df["DDR5_latency_ns"] * 1e6
    df["CXL_bandwidth_MBps"] = df["size_kb"] / df["CXL_latency_ns"] * 1e6

    plt.figure(figsize=(8, 6))
    sns.lineplot(data=df, x="size_kb", y="DDR5_bandwidth_MBps", label="DDR5")
    sns.lineplot(data=df, x="size_kb", y="CXL_bandwidth_MBps", label="CXL-Type3")
    plt.xlabel("Access Size (KB)")
    plt.ylabel("Bandwidth (MB/s)")
    plt.title("DDR5 vs CXL Memory Bandwidth Curve")
    plt.grid(True)
    plt.savefig(os.path.join(RESULTS_DIR, "bandwidth_curve.png"), dpi=600)
    plt.show()

if __name__ == "__main__":
    plot_latency_and_bandwidth()
